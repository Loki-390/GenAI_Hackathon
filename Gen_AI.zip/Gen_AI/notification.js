function goBack() {
    window.history.back(); // navigate back to previous page
}
