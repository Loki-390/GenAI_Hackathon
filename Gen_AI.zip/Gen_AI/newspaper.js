
    // Data for newspapers
    const newspapers = {
      english: [
        { name: 'The Times of India', logo: 'https://timesofindia.indiatimes.com/apple-touch-icon.png' },
        { name: 'Hindustan Times', logo: 'https://images.hindustantimes.com/images/favicon/apple-touch-icon.png' }
      ],
      tamil: [
        { name: 'Dina Thanthi', logo: 'https://www.dailythanthi.com/assets/images/favicon.png' },
        { name: 'Dinamalar', logo: 'https://www.dinamalar.com/images/apple-touch-icon.png' }
      ],
      hindi: [
        { name: 'Dainik Bhaskar', logo: 'https://www.bhaskar.com/favicon.png' },
        { name: 'Navbharat Times', logo: 'https://static.abplive.com/img/desktop/apple-touch-icon-72x72.png' }
      ],
      telugu: [
        { name: 'Eenadu', logo: 'https://www.eenadu.net/images/fav-icon.png' },
        { name: 'Andhra Jyothy', logo: 'https://www.andhrajyothy.com/favicon.ico' }
      ],
      malayalam: [
        { name: 'Malayala Manorama', logo: 'https://www.manoramonline.com/favicon.ico' },
        { name: 'Mathrubhumi', logo: 'https://www.mathrubhumi.com/images/apple-touch-icon.png' }
      ],
      kannada: [
        { name: 'Vijaya Karnataka', logo: 'https://vijaykarnataka.com/favicon.ico' },
        { name: 'Prajavani', logo: 'https://www.prajavani.net/favicon.ico' }
      ]
    };

    // Function to switch views
    function showView(viewId) {
      document.querySelectorAll('.view').forEach(v => v.style.display = "none");
      document.getElementById(viewId).style.display = "flex";
    }

    // Language selection event
    document.getElementById('languageList').addEventListener('click', (e) => {
      const item = e.target.closest('.newspaper-item');
      if (item) {
        const lang = item.dataset.lang;
        const newspaperList = document.getElementById('newspaperList');
        const title = document.getElementById('newspaperTitle');

        newspaperList.innerHTML = '';
        title.textContent = `${lang.charAt(0).toUpperCase() + lang.slice(1)} Newspapers`;

        if (newspapers[lang]) {
          newspapers[lang].forEach(paper => {
            const div = document.createElement('div');
            div.className = 'newspaper-item';
            div.innerHTML = `<img src="${paper.logo}" alt="${paper.name} logo"><span>${paper.name}</span>`;
            newspaperList.appendChild(div);
          });
        }

        showView('newspaperView');
      }
    });

    // Search (placeholder)
    function searchNews() {
      const searchTerm = document.getElementById('searchTerm').value;
      const date = document.getElementById('dateInput').value;
      const year = document.getElementById('yearSelect').value;
      alert(`Searching for:\nTerm: "${searchTerm}"\nDate: ${date}\nYear: ${year}`);
    }
  


    function goBack() {
    window.history.back(); // navigate back to previous page
}
