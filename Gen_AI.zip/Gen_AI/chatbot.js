
        const chatBox = document.getElementById("chatBox");
        const chatInput = document.getElementById("chatInput");
        const panels = document.querySelectorAll(".keyboard-panel");

        function togglePanel(id) {
            panels.forEach(p => p.style.display = "none");
            const panel = document.getElementById(id);
            panel.style.display = panel.style.display === "block" ? "none" : "block";
        }



function goBack() {
    window.history.back(); // This will navigate back to the previous page
}

        function sendMessage() {
            const text = chatInput.value.trim();
            if (text === "") return;
            const msg = document.createElement("div");
            msg.classList.add("message", "sent");
            msg.textContent = autoCorrect(text);
            chatBox.appendChild(msg);
            chatBox.scrollTop = chatBox.scrollHeight;
            chatInput.value = "";
        }

        // Click on emoji/sticker/number
        document.querySelectorAll(".keyboard-panel span, .keyboard-panel img").forEach(el => {
            el.addEventListener("click", () => {
                if (el.tagName === "IMG") {
                    sendSticker(el.src);
                } else {
                    chatInput.value += el.textContent;
                }
            });
        });

        function sendSticker(src) {
            const msg = document.createElement("div");
            msg.classList.add("message", "sent");
            msg.innerHTML = `<img src="${src}" width="60">`;
            chatBox.appendChild(msg);
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        // Simple autocorrect dictionary
        function autoCorrect(text) {
            const corrections = { "helo": "hello", "gm": "good morning", "thx": "thanks" };
            return corrections[text.toLowerCase()] || text;
        }

        // Language change (demo effect only)
        document.getElementById("languageSelect").addEventListener("change", e => {
            alert("Language switched to " + e.target.value);
        });

        // Add event listener for the "Enter" key on the input field
        chatInput.addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                sendMessage();
            }
        });
    