
    const quotesData = {
        "happy": { quote: "The only joy in the world is to begin.", author: "Cesare Pavese", image: "colorful happy landscape" },
        "sad": { quote: "The good life is a process, not a state of being.", author: "Carl Rogers", image: "serene melancholic reflection" },
        "tired": { quote: "Rest and self-care are so important. When you take time to replenish your spirit, it allows you to serve others from a fuller vessel.", author: "Eleanor Brownn", image: "peaceful restful scenery" },
        "anxious": { quote: "The greatest weapon against stress is our ability to choose one thought over another.", author: "William James", image: "calming abstract patterns" },
        "stressed": { quote: "Almost everything will work again if you unplug it for a few minutes, including you.", author: "Anne Lamott", image: "relaxing nature scene" },
        "calm": { quote: "Breathe. Let go. And remind yourself that this very moment is the only one you know you have for sure.", author: "Oprah Winfrey", image: "tranquil ocean sunset" },
        "inspired": { quote: "The best way to predict the future is to create it.", author: "Abraham Lincoln", image: "vibrant abstract art with uplifting colors" }
    };

    const defaultQuote = { quote: "Type a mood to get a quote!", author: "", image: "abstract colorful background" };

    const moodInput = document.getElementById('moodInput');
    const quoteText = document.getElementById('quoteText');
    const quoteAuthor = document.getElementById('quoteAuthor');
    const quoteImageElement = document.getElementById('quoteImage');

    async function displayQuote() {
        const mood = moodInput.value.toLowerCase().trim();
        const data = quotesData[mood] || defaultQuote;

        quoteText.textContent = data.quote;
        quoteAuthor.textContent = data.author;

        // Simulate image generation
        const imagePrompt = data.image;
        if(imagePrompt) {
            quoteImageElement.src = await generateImage(imagePrompt);
        } else {
            quoteImageElement.src = '';
        }
    }

    async function generateImage(prompt) {
        // Placeholder images based on prompt
        if(prompt.includes("happy")) return "https://images.unsplash.com/photo-1502759683299-cdcd6974244f?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        if(prompt.includes("sad")) return "https://images.unsplash.com/photo-1506744038136-413ff78cdb5e?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        if(prompt.includes("tired")) return "https://images.unsplash.com/photo-1547483134-2e947d674176?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        if(prompt.includes("anxious")) return "https://images.unsplash.com/photo-1472214098495-a1312384957e?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        if(prompt.includes("stressed")) return "https://images.unsplash.com/photo-1500382017468-9049cee7dafc?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        if(prompt.includes("inspired")) return "https://images.unsplash.com/photo-1517404215737-0129a0a0b271?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
        return "https://images.unsplash.com/photo-1502444330042-33022560377c?q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max";
    }

    document.querySelectorAll('.color-tab, .emoji-list span').forEach(item => {
        item.addEventListener('click', () => {
            const mood = item.dataset.mood;
            if(mood) {
                moodInput.value = mood;
                displayQuote();
            }
        });
    });

    moodInput.addEventListener("keypress", function(event) {
        if(event.key === "Enter") displayQuote();
    });
