
        // --- Physical Activity ---
        function rateActivity(activity) {
            const ratingText = document.querySelector('#activityRating .rating-text');
            const motivationText = document.querySelector('#activityRating .motivation-text');
            let rating = '';
            let motivation = '';
            let colorClass = '';

            if (activity === 'light') {
                rating = 'Light Activity';
                colorClass = 'rating-light';
                motivation = 'Way to go! A light walk clears your head.';
            } else if (activity === 'moderate') {
                rating = 'Moderate Activity';
                colorClass = 'rating-moderate';
                motivation = 'Awesome effort! Keep going strong.';
            } else if (activity === 'intense') {
                rating = 'Intense Activity';
                colorClass = 'rating-intense';
                motivation = 'Incredible! Feel the power of your workout!';
            }

            ratingText.textContent = rating;
            ratingText.className = `rating-text ${colorClass}`;
            motivationText.textContent = motivation;
        }

        // --- Breathing Timer ---
        let timerInterval;
        let totalSeconds = 0;
        const timerDisplay = document.getElementById('timerDisplay');
        const breathingInstruction = document.getElementById('breathingInstruction');
        const timerCircle = document.getElementById('breathingTimer');

        function updateTimerDisplay() {
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;
            timerDisplay.textContent = `${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;
        }

        function startBreathingTimer() {
            if (timerInterval) clearInterval(timerInterval);

            let breathState = 'in';
            timerCircle.style.transform = 'scale(1.2)';
            breathingInstruction.textContent = "Breathe in...";

            timerInterval = setInterval(() => {
                totalSeconds--;
                updateTimerDisplay();

                if (totalSeconds <= 0) {
                    clearInterval(timerInterval);
                    timerCircle.style.transform = 'scale(1)';
                    breathingInstruction.textContent = "Exercise Complete!";
                    timerDisplay.textContent = "Done!";
                } else if (totalSeconds % 8 === 0) {
                    breathState = breathState === 'in' ? 'out' : 'in';
                    breathingInstruction.textContent = breathState === 'in' ? "Breathe in..." : "Breathe out...";
                    timerCircle.style.transform = breathState === 'in' ? 'scale(1.2)' : 'scale(1)';
                }
            }, 1000);
        }

        function stopBreathingTimer() {
            clearInterval(timerInterval);
            breathingInstruction.textContent = "Paused";
            timerCircle.style.transform = 'scale(1)';
        }

        function setBreathingTime() {
            const minutes = document.getElementById('breathingTimeInput').value;
            if (minutes && minutes > 0) {
                totalSeconds = minutes * 60;
                updateTimerDisplay();
                breathingInstruction.textContent = `Set for ${minutes} minutes. Ready to start?`;
            } else {
                alert('Please enter a valid number of minutes.');
            }
        }

        // --- Diet Plan ---
        function calculateDietPlan() {
            const weight = document.getElementById('weight').value;
            const age = document.getElementById('age').value;
            const resultDiv = document.getElementById('dietPlanResult');

            if (!weight || !age) {
                resultDiv.innerHTML = '<h4>Please enter your weight and age.</h4>';
                return;
            }

            let plan = '';
            if (age < 18) {
                plan = "Consult a doctor for a personalized diet plan.";
            } else if (weight < 50) {
                plan = "Eat nutrient-rich foods: fruits, vegetables, and lean protein.";
            } else if (weight >= 50 && weight < 80) {
                plan = "Balanced diet: whole grains, leafy greens, and proteins.";
            } else {
                plan = "More fiber, protein, and hydration with plenty of water.";
            }

            resultDiv.innerHTML = `<h4>Your Personalized Diet Plan:</h4><p>${plan}</p>`;
        }
    


        function goBack() {
    window.history.back(); // navigate back to previous page
}
