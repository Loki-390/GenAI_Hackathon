
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    function addMessage(text, type) {
      const msg = document.createElement('div');
      msg.classList.add('message', type);
      msg.innerHTML = text;
      chatBox.appendChild(msg);
      chatBox.scrollTop = chatBox.scrollHeight;
    }

    sendBtn.addEventListener('click', () => {
      const text = userInput.value.trim();
      if (text) {
        addMessage(text, 'sent');
        userInput.value = '';
        setTimeout(() => {
          addMessage("💡 Thanks for sharing. I'm here for you!", 'received');
        }, 800);
      }
    });

    // Emoji responses
    const emojiResponses = {
      "😊": "I'm glad you're feeling happy! 🌟",
      "😢": "I'm sorry to hear that. It's okay to feel sad sometimes 💖",
      "😡": "Anger can be tough. Try taking a deep breath 🌬️",
      "😴": "You must be tired. Rest is important 😌",
      "🤔": "You're thinking deeply 🤔 I'm here if you want to share!"
    };

    document.querySelectorAll('.emoji').forEach(e => {
      e.addEventListener('click', () => {
        const emoji = e.textContent;
        addMessage(emoji, 'sent');
        setTimeout(() => {
          addMessage(emojiResponses[emoji] || "Thanks for sharing your feelings 💕", 'received');
        }, 600);
      });
    });

    // Stickers
    document.querySelectorAll('.sticker').forEach(s => {
      s.addEventListener('click', () => {
        addMessage(s.textContent, 'sent');
        setTimeout(() => {
          addMessage("That's a fun sticker! 🎉", 'received');
        }, 600);
      });
    });

    // Quick replies with specific responses
    const quickReplyResponses = {
      "I'm feeling anxious": "It's okay to feel anxious 💕 Try taking a slow breath with me 🌬️",
      "Can you calm me down?": "Of course 🌸 Close your eyes and imagine a peaceful place 🕊️",
      "I need motivation": "You are stronger than you think 💪 Keep going, I believe in you! ✨"
    };

    document.querySelectorAll('.quick-reply').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.textContent;
        addMessage(text, 'sent');
        setTimeout(() => {
          addMessage(quickReplyResponses[text] || "💡 Thanks for sharing. I'm here for you!", 'received');
        }, 600);
      });
    });
  