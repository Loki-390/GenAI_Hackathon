// Animate cards one by one (if cards exist on this page)
const cards = document.querySelectorAll(".card");
cards.forEach((card, index) => {
  setTimeout(() => {
    card.classList.add("show");
  }, 200 * index);
});

// Redirect after 3 seconds to your main app
setTimeout(() => {
  window.location.href = "index.html";  // make sure index.html is in same folder
}, 3000);
