
        // Animate cards one by one
        const cards = document.querySelectorAll(".card");
        cards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add("show");
        }, 200 * index);
        });
    

        